﻿namespace DesktopApp1
{
}

namespace DesktopApp1
{


    public partial class Database1DataSet
    {
    }
}
